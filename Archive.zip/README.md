pnpm i           # or npm i
pnpm migrate     # or npm run migrate
pnpm start       # or npm start
